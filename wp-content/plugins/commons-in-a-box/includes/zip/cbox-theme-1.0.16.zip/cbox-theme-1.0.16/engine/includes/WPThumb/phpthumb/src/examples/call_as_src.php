<h1>Calling PHPThumb As &lt;img src="&hellip;" /&gt;</h1>

<p><strong>Original</strong></p>
<p>
<img src="/src/examples/test.jpg" />
</p>

<p><strong>Modified</strong></p>
<p>
<img src="/src/PHPThumb.php?src=/src/examples/test.jpg&w=200" />
</p>